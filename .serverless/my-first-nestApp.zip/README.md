# start_command : `npm run start`
# start application in watch mode: `npm run start:dev`

** TO PERFORM CRUD OPERATION PLEASE GO THROOUGH THE BELLOW API_URL
# TO CREATE USER: `localhost:3000/user`
# Get_user : `localhost:3000/user`
# Get_user_byID: `localhost:3000/user/:id`
# Update_user : `localhost:3000/user/:id`
# delete_user: `localhost:3000/user/:id`
** AUTHENTICATION USING PASSPORT-JWT
# signup : `localhost:3000/auth/signup`
# login : `localhost:3000/auth/login`

# SOCKET.IO GATEWAY AND CURD OPERATION API COLLECTION MAKE IN POSTMAN COLLECTION 

# I USE SERVERLESS AWS FOR DEPLOY MY APP(I USE MY OWN AWS CREDENTIALS) , IT IS DONE SUCCESSFULLY BUT THE DEPLOY LINK DOSE NOT WORK ,IT THROUGH INTERNAL SERVER ERROR.
# DEPLOY LINK :`https://6tgyv9citc.execute-api.us-east-1.amazonaws.com/prod/` & `https://6tgyv9citc.execute-api.us-east-1.amazonaws.com/prod/%7Bproxy+%7D`


